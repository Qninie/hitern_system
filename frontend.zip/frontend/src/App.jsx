import Login from "./pages/login"
import UploadDocument from "./pages/uploadDocument"
import Documents from "./pages/documents"
import Layout from "./layout"

function App() {
  return (
    <Layout>
      <Documents />
    </Layout>
  )
}

export default App

