function Layout({ children }) {
  return (
    <div className="flex">

      {/* Sidebar */}
      <div className="w-64 bg-red-600 text-white min-h-screen p-4">
        <h2 className="text-xl font-bold mb-6">Hitern</h2>
        <ul className="space-y-3">
          <li>Dashboard</li>
          <li>Upload</li>
          <li>Documents</li>
          <li>Notifications</li>
        </ul>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-6 bg-gray-50">
        {children}
      </div>

    </div>
  )
}

export default Layout